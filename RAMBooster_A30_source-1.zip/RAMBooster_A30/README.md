# RAM Booster — Galaxy A30 / LineageOS 23.2

Projeto Android nativo em Kotlin, configurado para `arm64-v8a` por padrão no APK universal gerado pelo Android Gradle Plugin (sem bibliotecas nativas externas).

## O que faz
- Mostra RAM total, usada e disponível usando `ActivityManager.MemoryInfo`.
- Atualiza os números automaticamente a cada segundo enquanto o app está aberto.
- Abre as configurações do Android para gerenciar aplicativos.

## Limitação importante
Android/LineageOS não permite que um aplicativo comum encerre à força processos de outros aplicativos. O botão de gerenciamento abre as configurações do sistema para que o usuário escolha o que encerrar. O app não promete “liberar” RAM artificialmente; o Android usa RAM livre como cache para deixar o sistema mais rápido.

## Como gerar o APK
1. Instale o Android Studio em um computador.
2. Abra a pasta `RAMBooster_A30`.
3. Aguarde a sincronização do Gradle.
4. Se solicitado, instale Android SDK Platform 36.
5. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. O APK será gerado em `app/build/outputs/apk/debug/app-debug.apk`.

Compatibilidade: Android 6.0 ou superior; interface preparada para Android 16 / LineageOS 23.2. Não exige root.
