package com.example.rambooster

import android.app.Activity
import android.app.ActivityManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var ramText: TextView
    private lateinit var detailText: TextView
    private lateinit var statusText: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val refreshTask = object : Runnable {
        override fun run() {
            updateRam()
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(32), dp(24), dp(24))
            setBackgroundColor(0xFF101827.toInt())
        }

        val title = TextView(this).apply {
            text = "RAM BOOSTER"
            textSize = 24f
            setTextColor(0xFFFFFFFF.toInt())
            typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(title)

        val subtitle = TextView(this).apply {
            text = "Galaxy A30 • LineageOS"
            textSize = 14f
            setTextColor(0xFFB8C7DC.toInt())
            setPadding(0, dp(8), 0, dp(28))
        }
        root.addView(subtitle)

        ramText = TextView(this).apply {
            textSize = 38f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFF69B7FF.toInt())
            gravity = Gravity.CENTER
        }
        root.addView(ramText)

        detailText = TextView(this).apply {
            textSize = 16f
            setTextColor(0xFFE6EDF7.toInt())
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(28))
        }
        root.addView(detailText)

        statusText = TextView(this).apply {
            text = "Atualização automática ativada"
            textSize = 14f
            setTextColor(0xFF9FB1C9.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(20))
        }
        root.addView(statusText)

        val refreshButton = makeButton("ATUALIZAR AGORA")
        refreshButton.setOnClickListener {
            updateRam()
            statusText.text = "Dados atualizados."
        }
        root.addView(refreshButton)

        val settingsButton = makeButton("GERENCIAR APLICATIVOS")
        settingsButton.setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS))
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_APPLICATION_SETTINGS))
            }
        }
        root.addView(settingsButton)

        val note = TextView(this).apply {
            text = "Importante: o Android gerencia a RAM automaticamente. Este app monitora a memória e abre as configurações para você encerrar manualmente apps que não estiver usando. Ele não força o fechamento de outros aplicativos."
            textSize = 12f
            setTextColor(0xFF9FB1C9.toInt())
            gravity = Gravity.CENTER
            setPadding(0, dp(28), 0, 0)
        }
        root.addView(note)

        setContentView(root)
        updateRam()
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(refreshTask)
        handler.post(refreshTask)
    }

    override fun onPause() {
        handler.removeCallbacks(refreshTask)
        super.onPause()
    }

    private fun updateRam() {
        val manager = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        manager.getMemoryInfo(info)

        val total = info.totalMem.toDouble()
        val available = info.availMem.toDouble()
        val used = (total - available).coerceAtLeast(0.0)
        val percent = if (total > 0) (used / total * 100).toInt() else 0

        ramText.text = "$percent% em uso"
        detailText.text = "Usada: ${formatGb(used)} GB\nDisponível: ${formatGb(available)} GB\nTotal: ${formatGb(total)} GB"
        statusText.text = if (info.lowMemory) {
            "Aviso: o Android sinaliza pouca memória disponível."
        } else {
            "Memória acompanhada em tempo real"
        }
    }

    private fun formatGb(bytes: Double): String =
        String.format(Locale.getDefault(), "%.2f", bytes / (1024.0 * 1024.0 * 1024.0))

    private fun makeButton(label: String): Button = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 15f
        setTextColor(0xFFFFFFFF.toInt())
        setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF1769AA.toInt()))
        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        params.bottomMargin = dp(12)
        layoutParams = params
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
